%singleProfileRun
%   Runs a single power profile based on one driving cycle. There is an
%   option to run this profile multiple times
%
%Change Log
%   REVISION    CHANGE                                          DATE-YYMMDD
%   00          Initial Revision from                           190116
%               BattTest_PowerProfile_rev1


% clearvars;
clc;

try
    %% Setup Code
    
    cellID = "AA7"; % ID in Cell Part Number (e.g BAT11-FEP-AA1). Defined again in initializeVariables

    
    % IMPORT CURRENT PROFILE
    % matFile = '003EUDC_CurrProfile';
    matFile = "002_" + cellID + "_CurrProfiles";
    load(matFile, 'cycleProfiles'); % Driving cycle variable name is "currProfile"
%     currProfile = timeseries(-currProfile.Data, currProfile.Time);
    currProfile = timeseries(cycleProfiles(1).data(6726:7033), cycleProfiles(1).Time(6726:7033)-cycleProfiles(1).Time(6726));
    % Initializations
    script_initializeVariables; % Run Script to initialize common variables
    script_initializeDevices; % Initialized devices like Eload, PSU etc.
    numIterations = 1; % Number of times to run the profile
    writePeriod = 0.4; % Period to resample the input current profile
    
    plotFigs = true;
    currArr = [];
    % Resamples the input profile to the interval given in readPeriod
    currProfile = resample(currProfile, currProfile.Time(1):writePeriod:currProfile.Time(length(currProfile.Time)));
    % ard = arduino();
    % v=0;ain = []; curr = []; currArd = [];
    
    %% Script
    tic; % Start Timer
    for i = 1:numIterations
        counter = 1; %In order for the sampling of data from profile
        % to be based on the number of samples
        
        profileLen = length(currProfile.Time);
        
        timerPrev(1) = toc;
        timerPrev(2) = timerPrev(1);
        
        % While Loop: Runs through the currProfile based on the sampling
        while counter <= profileLen
            %% Commands
            % Evaluates and changes commands based on the timing provided on the
            % profile
            if toc - timerPrev(2) >= currProfile.Time(counter)
                %             disp ("in Time = " + num2str(toc));
                %             disp("profile Time = " + num2str(currProfile.Time(counter)));
                % Evaluator
                % If the next current value is positive and the battery is
                % currently charging, discharge the battery
                % or else charge the battery (charging is simulating regen braking
                if (round(currProfile.Data(counter),1) < 0)
                    chargeReq = false; % Make next command a discharge command
                    curr = currProfile.Data(counter);
                elseif (round(currProfile.Data(counter),1) > 0)
                    chargeReq = true; % Make next command a charge command
                    curr = currProfile.Data(counter);
                else
                    chargeReq = 3; % Not charging or discharging
                end
                if counter == 2
                    disp(chargeReq)
                end
                disp("curr = " + num2str(curr));                
                currArr(end+1) = curr;

                %             disp("counter = " + num2str(counter));
                
                disp("Before Comand ; " + num2str(toc) + " seconds");
                
                % Charge Command
                if (chargeReq == true)
                    script_charge; % Run Script to begin/update charging process
%                     pause (0.15)
                    % Discharge Command
                elseif (chargeReq == false)
                    script_discharge; % Run Script to begin/update discharging process
                else
                    script_idle; % Run Script
                end
                disp(battState +" ; " + num2str(toc) + " seconds");
                                
                script_queryData; % Runs the script that queries data from the devices. Stores the results in the [dataCollection] Variable
                script_failSafes; %Run FailSafe Checks
                % if limits are reached, break loop
                if errorCode == 1
                    break;
                end
                
                counter = counter + 1;
                %             disp ("out Time = " + num2str(toc));
            end % End of IF toc
        end % While Loop
        timerPrev(2) = toc;
    end % For Loop for numIterations
    
    % battTS = delsample(battTS, 'Index', 1);
    %
    battTS.Time = battTS.Time - battTS.Time(1);
    
    if plotFigs == true
        plot(battTS.Time, battTS.Data(:,1),battTS.Time, battTS.Data(:,2), battTS.Time, currArr)
        hold on;
        plot(currProfile);
        legend('battVolt','battCurr','profile Set', 'profile');
    end
    if length(matFile) >= 4
%         save(dataLocation + "009RunProfileData_" + matFile(4:8) + ".mat", 'battTS', '-v7.3');
    end
    %% Teardown Section
    
    script_resetDevices; % Runs the resetDevices script
    
catch ME
    script_resetDevices;
    rethrow(ME);
end
