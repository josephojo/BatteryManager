%BattTest
%
%Change Log
%   REVISION    CHANGE                                          DATE-YYMMDD
%   00          Initial Revision from BattTest_Basic_rev2       190107
%   01          Implemented batt mgmt framework from            190107
%               drving cycles

clear;
clc;

%% Setup Code


%ARRAY ELOAD
%##########################################################################
eload = Array_ELoad('COM2');
%--------------------------------------------------------------------------

%BK PRECISION POWER SUPPLY
%##########################################################################
psu = BK_PSU('COM4');
%--------------------------------------------------------------------------

%THERMOCOUPLE MODULE
%##########################################################################
thermo = modbus('serialrtu','COM5','Timeout',10); % Initializes a Modbus
%protocol object using serial RTU interface connecting to COM6 and a Time
%out of 10s.
thermo.BaudRate = 38400;
%--------------------------------------------------------------------------

% LABJACK
%##########################################################################

ljasm = NET.addAssembly('LJUDDotNet');
ljudObj = LabJack.LabJackUD.LJUD;

% Open the first found LabJack U3.
[ljerror, ljhandle] = ljudObj.OpenLabJackS('LJ_dtU3', 'LJ_ctUSB', '0', ...
    true, 0);

% Constant values used in the loop.
LJ_ioGET_AIN = ljudObj.StringToConstant('LJ_ioGET_AIN');
LJ_ioGET_AIN_DIFF = ljudObj.StringToConstant('LJ_ioGET_AIN_DIFF');
LJE_NO_MORE_DATA_AVAILABLE = ljudObj.StringToConstant('LJE_NO_MORE_DATA_AVAILABLE');

% Start by using the pin_configuration_reset IOType so that all pin
% assignments are in the factory default condition.
ljudObj.ePutS(ljhandle, 'LJ_ioPIN_CONFIGURATION_RESET', 0, 0, 0);
% -------------------------------------------------------------------------

% IMPORT DRIVING CYCLE

load("out_LA4_mps"); % Driving cycle variable name is "cyc_mps"

pwrProfile = 2241 * (cyc_mps(2,:) .* cyc_mps(3,:)); % Converts driving
% cycle to power profile: P = (m*a)*v. Where a and v are
% given in cyc_mps and m is assumed to be 2,241kg
% which is the weight of the 2018 Tesla Model S P100D

maxPwr = max(pwrProfile);
minPwr = min(pwrProfile);
divisor = max(abs(minPwr), abs(maxPwr));

scaledPwrProfile = pwrProfile / divisor;

% OUTPUT FILE
%##########################################################################
dateString = cellstr(datetime('now', 'Format', 'yyMMdd'));
fileName = "Data\data-" + dateString + "_5D-C_Cycle01.csv";

if isfile(fileName)
    % If File exists. append new data to it
    fileID = fopen(fileName, 'at+');
else
    % File does not exist. Create new one and add the top row
    fileID = fopen(fileName, 'at+');
    fprintf(fileID,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n", "Date", ...
        "Time", "Duration (s)", "PSU Voltage", "PSU Current", ...
        "PSU Mode", "ELoad Voltage", "ELoad Current","Ambient Temp", "Surface Temp", ...
        "Core Temp","Battery Voltage","Battery State", "Error Code");
end
% -------------------------------------------------------------------------
psu.Disconnect();
eload.Disconnect();

% Initializations
tic; % Started the timer function
timerPrev = zeros(1, 5); % Creates an array that will be used to record previous time measurements

psuData = zeros(1, 2);
eloadData = zeros(1, 2);
ain3 = 0; ain2 = 0; adcAvgCounter = 0;
adcAvgCount = 50;

highVoltLimit = 3.65; % Actually 3.7V, but for protection: 3.6V
lowVoltLimit  = 2.85; % Actually 2.8V, but for protection: 2.9V

chargeReq = 0; % Charge Request - true/1 = Charging, false/0 = discharging
% chargeState = false; % chargeState - Is the PSU currently active? Prevents
%                       % the code from running through another charging
%                       % routine if it is already chaging
% dischargeState = false; % dischargeState - Is the battery currently discharging?
battState = ""; % State of the battery ("Charging", "Discharging or idle")
battVolt = 0; % Measured Voltage of the battery
maxBattVoltLimit = 3.70; % Maximum Voltage limit of the operating range of the battery
minBattVoltLimit = 2.80; % Minimum Voltage limit of the operating range of the battery
battSurfTempLimit = 45.0; % Maximum Surface limit of the battery
battCoreTempLimit = 50.0; % Maximum Core limit of the battery

chargeVolt = 4.2; % Charge Voltage - Voltage at which to charge the battery
currProfile = (scaledPwrProfile / chargeVolt)* 50; % 50 is the max discharge
% current according to battery datasheet (ANR26650)
profilePeriod = 1; %Datapoints in profile have a period of 1 second
readPeriod = 1; % Number of seconds to wait before reading values from devices


%% Script

% runCode = "test";
runCode = "main";

if strcmp(runCode, "test")
    %% Code Testing Section
    
    psuReply = psu.SetVolt(3.3); disp("psu Volt set: " + psuReply);
    psuReply = psu.SetCurr(0.5); disp("psu Curr set: " + psuReply);
    
    eloadReply = eload.SetLev_CC(0.5); disp("eload CC set: " + eloadReply);
    
    psu.Connect();
    eload.Connect();
    
    relayState = true;
    
    relayState = ~relayState;
    disp ("relayState = " + relayState);%disp (relayState)
    ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,relayState, 0);
    ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 5,relayState, 0);
    ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 6,relayState, 0);
    wait(0.3);
    
    for i = 1:10
        [psuData, psuMode] = psu.GetVoltCurrD();
        disp("Voltage at PSU = " + psuData(1)+ " V");
        disp("Current at PSU = " + psuData(2)+ " A"+ newline);
        
        eloadCurr = eload.MeasureCurr();
        disp("Current at ELoad = " + num2str(eloadCurr,'%.3f')+ " A" + newline);
        
        %Measure Data from thermometer. Since Data sent is multiplied by 10,
        %need to divide it by 10 to be understandable
        thermoData = read(thermo,'holdingregs',1,1)/10; %
        %     disp("Temp at Thermocouple = " + thermoData + newline);
        
        wait(1);
    end
    
elseif strcmp(runCode, "main")
    
    %% Main Code Section
    
    profileCounter = 0;
    
    % profileCounter WHILE LOOP - Runs currProfile size times
    while (profileCounter < size(currProfile,2))
        
        % Evaluates and changes commands every profilePeriod second(s)
        if toc - timerPrev(2) >= profilePeriod
            timerPrev(2) = toc;
            
            % Evaluator
            % If the next current value is positive and the battery is
            % currently charging, discharge the battery
            % or else charge the battery (charging is simulating regen braking
            if (currProfile(profileCounter) > 0) %&& (chargeState == true)
                chargeReq = false; % Make next command a discharge command
            elseif (currProfile(profileCounter) < 0) %&& (dischargeState == true)
                chargeReq = true; % Make next command a charge command
            else
                chargeReq = 3; % Not charging or discharging
            end
            
            % Charge Command
            if (chargeReq == true) % && chargeState == false)
                psu.Disconnect();
                eload.Disconnect();
                %                 dischargeState = false; % Allows discharge command to run if requested
                
                relayState = false; % Relay is in the Normally Opened Position
                disp ("Charging...");
                ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,relayState, 0);
                ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 5,relayState, 0);
                ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 6,relayState, 0);
                wait(0.16); % Wait for the relays to switch
                
                psuReply = psu.SetVolt(chargeVolt); %disp("psu Volt set: " + psuReply);
                psuReply = psu.SetCurr(chargeCurr); %disp("psu Curr set: " + psuReply);
                psu.Connect();
                
                %                 chargeState = true; % Prevents charge command from running multiple times in while loop
                battState = "charging";
                timerPrev(3) = toc; % initial charge or Discharge time in seconds
                
                % Discharge Command
            elseif (chargeReq == false) % && dischargeState == false)
                eload.Disconnect();
                psu.Disconnect();
                %                 chargeState = false; % Allows charge command to run if requested
                
                relayState = true; % Relay is in the Normally Closed Position
                disp ("Discharging...");
                ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,relayState, 0);
                ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 5,relayState, 0); % Current Relay 1
                ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 6,relayState, 0); % Current Relay 2
                wait(0.16); % Wait for the relays to switch
                
                eloadReply = eload.SetLev_CC(dischargeCurr); %disp("eload CC set: " + eloadReply);
                eload.Connect();
                
                %                 dischargeState = true; % Prevents discharge command from running multiple times in while loop
                battState = "discharging";
                timerPrev(3) = toc; % initial charge or Discharge time in seconds
            else
                eload.Disconnect();
                psu.Disconnect();
                
                relayState = true; % Relay is in the Normally Closed Position
                disp ("Battery Idle");
                ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,relayState, 0);
                ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 5,relayState, 0); % Current Relay 1
                ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 6,relayState, 0); % Current Relay 2
                %                 wait(0.12); % Wait for the relays to switch
                battState = "idle";
                
            end
            
            
            profileCounter = profileCounter + 1;
        end
        
        %% Measurements
        
        % Due to the imprecision of the Labjack ADC (12bit)or 5mV variation
        % This section averages 50 individual values from 2 analog ports
        % vBattp (Vbatt+) and vBattn(Vbatt-) to stabilize the voltage
        % difference and attain a variation of �0.001 V or �1 mV
        while adcAvgCounter < adcAvgCount
            
            % Request a single-ended reading from AIN2 (VBatt+).
            ljudObj.AddRequestS(ljhandle, 'LJ_ioGET_AIN', 2, 0, 0, 0);
            
            % Request a single-ended reading from (VBatt-).
            ljudObj.AddRequestS(ljhandle, 'LJ_ioGET_AIN', 3, 0, 0, 0);
            %
            % Execute the requests.
            ljudObj.GoOne(ljhandle);
            
            [ljerror, ioType, channel, dblValue, dummyInt, dummyDbl] = ljudObj.GetFirstResult(ljhandle, 0, 0, 0, 0, 0);
            
            finished = false;
            while finished == false
                switch ioType
                    case LJ_ioGET_AIN
                        switch int32(channel)
                            case 2
                                ain2 = ain2 + dblValue;
                            case 3
                                ain3 = ain3 + dblValue;
                        end
                end
                
                try
                    [ljerror, ioType, channel, dblValue, dummyInt, dummyDbl] = ljudObj.GetNextResult(ljhandle, 0, 0, 0, 0, 0);
                catch e
                    if(isa(e, 'NET.NetException'))
                        eNet = e.ExceptionObject;
                        if(isa(eNet, 'LabJack.LabJackUD.LabJackUDException'))
                            % If we get an error, report it. If the error is
                            % LJE_NO_MORE_DATA_AVAILABLE we are done.
                            if(int32(eNet.LJUDError) == LJE_NO_MORE_DATA_AVAILABLE)
                                finished = true;
                                adcAvgCounter = adcAvgCounter + 1;
                            end
                        end
                    end
                    % Report non LJE_NO_MORE_DATA_AVAILABLE error.
                    if(finished == false)
                        throw(e)
                    end
                end
            end
        end
        
        % Querys all measurements every readPeriod second(s)
        if toc - timerPrev(4) >= readPeriod
            timerPrev(4) = toc;
            
            %Measure Data from PSU
            [psuData, psuMode] = psu.GetVoltCurrD();
            
            %Measure Data from ELoad
            eloadData = eload.MeasureVoltCurr();
            
            %Finds avg of total voltages collected at both batt terminals
            vBattp = ain2 / adcAvgCount;
            vBattn = ain3 / adcAvgCount;
            
            % Grabs new battery voltage and adds offset
            battVolt = vBattp - vBattn + 0.011;
            adcAvgCounter = 0; ain2 = 0; ain3 = 0;
            
            %Measure Data from thermometer. Since Data sent is multiplied by 10,
            %need to divide it by 10 to be understandable
            thermoData = read(thermo,'holdingregs',1,3);%/10;
            
            tElasped = toc - timerPrev(3);
            disp(num2str(tElasped,'%.1f') + "seconds");
            Pstr = sprintf("PSU Volt = %.3f V\t\tPSU Curr = %.3f A", psuData(1), psuData(2));
            Estr = sprintf("ELoad Volt = %.3f V\tELoad Curr = %.3f A",  eloadData(1), eloadData(2));
            Tstr = sprintf("TC 1 = %.1f �C\t\t\tTC 2 = %.1f �C\t\t\tTC 3 = %.1f �C" ,thermoData(1)/10, thermoData(2)/10, thermoData(3)/10);
            Bstr = sprintf("Batt Volt = %.3f V\t\tBatt State = %s\n\n", battVolt, battState);
            fprintf(Pstr + newline + Estr + newline + Tstr + newline + Bstr);
            
            dateString = datestr(datetime);
            dateTime = strsplit(dateString, ' ');
            
            fprintf(fileID,"%s,%s,",dateTime{1}, dateTime{2});
            fprintf(fileID,"%.1f,", tElasped);
            fprintf(fileID,"%.3f,%.3f,%s,", psuData(1), psuData(2), psuMode);
            fprintf(fileID,"%.3f,%.3f,",  eloadData(1), eloadData(2));
            fprintf(fileID,"%.1f,%.1f,%.1f,",thermoData(1)/10, thermoData(2)/10, thermoData(3)/10);
            fprintf(fileID,"%.3f,%s\n", battVolt, battState);
        end
        
        %% Fail Safes
        
        % if battery temperatures > limit, break loop
        if thermoData(2)/10 > battSurfTempLimit
            warning("WARNING - Surface Temp Exceeded Limit");
            fprintf(fileID,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",...
                "","","","","","","","","","","","","",...
                "WARNING - Surface Temp Exceeded Limit");
            break;
        elseif thermoData(3)/10 > battCoreTempLimit
            warning("WARNING - Core Temp Exceeded Limit");
            fprintf(fileID,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",...
                "","","","","","","","","","","","","",...
                "WARNING - Core Temp Exceeded Limit");
            break;
        elseif battVolt <= minBattVoltLimit || battVolt >= maxBattVoltLimit
            warning("WARNING - Battery Voltage Exceeded Limit");
            fprintf(fileID,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",...
                "","","","","","","","","","","","","",...
                "WARNING - Battery Voltage Exceeded Limit");
            break;
        end
        
    end % While Loop
end

%% Teardown Section

%Close file
fclose(fileID);

% Disconnects both charger and discharger FIRST(This is IMPORTANT!!) before the relays
psu.Disconnect();
eload.Disconnect();

% Puts the battery back in discharge mode
relayState = true;
ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,relayState, 0);
ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 5,relayState, 0);
ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 6,relayState, 0); % Current Relay 2
wait(0.3);
ljudObj.Close();

fclose(psu.SerialObj);
fclose(eload.SerialObj);



