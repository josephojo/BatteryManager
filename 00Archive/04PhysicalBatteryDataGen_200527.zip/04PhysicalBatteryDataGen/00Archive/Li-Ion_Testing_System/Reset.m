%Close file
% fclose(fileID);

% Puts the battery back in discharge mode
% relayState = true;
% ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,relayState, 0);
% ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 5,relayState, 0);
% ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 6,relayState, 0); % Current Relay 2
% wait(0.3);

% Disconnects both charger and discharger
psu.Disconnect();
eload.Disconnect();

fclose(psu.SerialObj);
fclose(eload.SerialObj);