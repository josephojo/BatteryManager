%BattTest
%
%Change Log
%   REVISION    CHANGE                                          DATE-YYMMDD
%   00          Initial Revision                                181124
%   01          Implemented battery Voltage measurement         181212


%% Setup Code

clear;
clc;

%ARRAY ELOAD
%##########################################################################
eload = Array_ELoad('COM2');
%--------------------------------------------------------------------------

%BK PRECISION POWER SUPPLY
%##########################################################################
psu = BK_PSU('COM4');
%--------------------------------------------------------------------------

%THERMOCOUPLE MODULE
%##########################################################################
thermo = modbus('serialrtu','COM5','Timeout',10); % Initializes a Modbus
%protocol object using serial RTU interface connecting to COM6 and a Time
%out of 10s.
thermo.BaudRate = 38400;
%--------------------------------------------------------------------------

% LABJACK
%##########################################################################

ljasm = NET.addAssembly('LJUDDotNet');
ljudObj = LabJack.LabJackUD.LJUD;

% Open the first found LabJack U3.
[ljerror, ljhandle] = ljudObj.OpenLabJackS('LJ_dtU3', 'LJ_ctUSB', '0', ...
    true, 0);

% Constant values used in the loop.
LJ_ioGET_AIN = ljudObj.StringToConstant('LJ_ioGET_AIN');
LJ_ioGET_AIN_DIFF = ljudObj.StringToConstant('LJ_ioGET_AIN_DIFF');
LJE_NO_MORE_DATA_AVAILABLE = ljudObj.StringToConstant('LJE_NO_MORE_DATA_AVAILABLE');

% Start by using the pin_configuration_reset IOType so that all pin
% assignments are in the factory default condition.
ljudObj.ePutS(ljhandle, 'LJ_ioPIN_CONFIGURATION_RESET', 0, 0, 0);
% -------------------------------------------------------------------------

% FILE
%##########################################################################
dateString = cellstr(datetime('now', 'Format', 'yyMMdd'));
fileName = "Data\data-" + dateString + ".csv";

if isfile(fileName)
    % If File exists. append new data to it
    fileID = fopen(fileName, 'at+');
else
    % File does not exist. Create new one and add the top row
    fileID = fopen(fileName, 'at+');
    fprintf(fileID,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n", "Date", ...
        "Time", "Duration (s)", "PSU Voltage", "PSU Current", ...
        "PSU Mode", "ELoad Voltage", "ELoad Current","TC 1", "TC 2", ...
        "Battery Voltage","Battery State", "Error Code");
end
% -------------------------------------------------------------------------

psu.Disconnect();
eload.Disconnect();

tic; % Started the timer function
timerPrev = zeros(1, 5); % Creates an array that will be used to record previous time measurements

chargeReq = 1; % Charge Request - true/1 = Charging, false/0 = discharging
chargeState = false; % chargeState - Is the battery currently charging?
dischargeState = false; % dischargeState - Is the battery currently discharging?
battState = ""; % State of the battery ("Charging" or "Discharging")
battVolt = 0; % Measured Voltage of the battery
maxBattVoltLimit = 3.70; % Maximum Voltage limit of the operating range of the battery
minBattVoltLimit = 2.90; % Minimum Voltage limit of the operating range of the battery
battSurfTempLimit = 35.0; % Maximum Surface limit of the battery

dischargeCurr = 1.0; % Discharge Current - Current at which to discharge the battery
chargeCurr = 1.0; % Charge Current - Current at which to charge the battery
chargeVolt = 3.7; % Charge Voltage - Voltage at which to charge the battery

duration = 60; %7200; % Charge / Discharge Duration (7200secs = 2Hrs)
readPeriod = 1; % Number of seconds to wait before reading values from devices 

highVoltLimit = 3.60; % Actually 3.7V, but for protection: 3.6V
lowVoltLimit  = 2.90; % Actually 2.8V, but for protection: 2.9V
chargeCount = 5;

psuData = zeros(1, 2);
eloadData = zeros(1, 2);
ain3 = 0; ain2 = ain3; adcAvgCounter = ain3;
adcAvgCount = 50;

%% Script

% runCode = "test";
runCode = "main";

if strcmp(runCode, "test")
    %% Code Testing Section
    
    psuReply = psu.SetVolt(3.3); disp("psu Volt set: " + psuReply);
    psuReply = psu.SetCurr(0.5); disp("psu Curr set: " + psuReply);
    
    eloadReply = eload.SetLev_CC(0.5); disp("eload CC set: " + eloadReply);
    
    psu.Connect();
    eload.Connect();
    
    relayState = true;
    
    relayState = ~relayState;
    disp ("relayState = " + relayState);%disp (relayState)
    ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,relayState, 0);
    ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 5,relayState, 0);
    
    for i = 1:10
        [psuData, psuMode] = psu.GetVoltCurrD();
        disp("Voltage at PSU = " + psuData(1)+ " V");
        disp("Current at PSU = " + psuData(2)+ " A"+ newline);
        
        eloadCurr = eload.MeasureCurr();
        disp("Current at ELoad = " + num2str(eloadCurr,'%.3f')+ " A" + newline);
        
        %Measure Data from thermometer. Since Data sent is multiplied by 10,
        %need to divide it by 10 to be understandable
        thermoData = read(thermo,'holdingregs',1,1)/10; %
        %     disp("Temp at Thermocouple = " + thermoData + newline);
        
        wait(1);
    end
    
elseif strcmp(runCode, "main")
    
    %% Main Code Section
    
    chargeCounter = 0; % Number of times to
    timerPrev(1) = toc;
    
    % Runs count number of times
    while (chargeCounter < chargeCount)
    %Runs while the duration is not met
%     while (toc - timerPrev(1) < duration)
           
        %% Charge Command
        
        if (chargeReq == true && chargeState == false)
            psu.Disconnect();
            dischargeState = false; % Allows discharge command to run if requested
            
            relayState = false; % Relay is in the Normally Opened Position
            disp ("Charging...");
            ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,relayState, 0);
            ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 5,relayState, 0);
            
            psuReply = psu.SetVolt(chargeVolt); disp("psu Volt set: " + psuReply);
            psuReply = psu.SetCurr(chargeCurr); disp("psu Curr set: " + psuReply);
            
            psu.Connect();
            chargeState = true; % Prevents charge command from running multiple times in while loop
            battState = "charging";
            timerPrev(3) = toc; % initial charge or Discharge time in seconds
        end
        
        %% Discharge Command
        
        if (chargeReq == false && dischargeState == false)
            eload.Disconnect();
            chargeState = false; % Allows charge command to run if requested
            
            relayState = true; % Relay is in the Normally Closed Position
            disp ("Discharging...");
            ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,relayState, 0);
            ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 5,relayState, 0);
            
            eloadReply = eload.SetLev_CC(dischargeCurr); disp("eload CC set: " + eloadReply);
            
            eload.Connect();
            dischargeState = true; % Prevents discharge command from running multiple times in while loop
            battState = "discharging";
            timerPrev(3) = toc; % initial charge or Discharge time in seconds
            
        end
        
        %% Measurements
        
        % Due to the imprecision of the Labjack ADC (12bit)or 5mV variation
        % This section averages 100 individual values from 2 analog ports
        % ain2 (Vbatt+) and ain3(Vbatt-) to stabilize the voltage
        % difference and attain a variation of �0.001 V or �1 mV
        while adcAvgCounter < adcAvgCount
            
            % Request a single-ended reading from AIN2.
            ljudObj.AddRequestS(ljhandle, 'LJ_ioGET_AIN', 2, 0, 0, 0);
            
            % Request a single-ended reading from AIN3.
            ljudObj.AddRequestS(ljhandle, 'LJ_ioGET_AIN', 3, 0, 0, 0);
%             
            % Execute the requests.
            ljudObj.GoOne(ljhandle);
            
            [ljerror, ioType, channel, dblValue, dummyInt, dummyDbl] = ljudObj.GetFirstResult(ljhandle, 0, 0, 0, 0, 0);
            
            finished = false;
            while finished == false
                switch ioType
                    case LJ_ioGET_AIN
                        switch int32(channel)
                            case 2
                                ain2 = ain2 + dblValue;
                            case 3
                                ain3 = ain3 + dblValue;
                        end
                end
                
                try
                    [ljerror, ioType, channel, dblValue, dummyInt, dummyDbl] = ljudObj.GetNextResult(ljhandle, 0, 0, 0, 0, 0);
                catch e
                    if(isa(e, 'NET.NetException'))
                        eNet = e.ExceptionObject;
                        if(isa(eNet, 'LabJack.LabJackUD.LabJackUDException'))
                            % If we get an error, report it. If the error is
                            % LJE_NO_MORE_DATA_AVAILABLE we are done.
                            if(int32(eNet.LJUDError) == LJE_NO_MORE_DATA_AVAILABLE)
                                finished = true;
                                adcAvgCounter = adcAvgCounter + 1;
                            end
                        end
                    end
                    % Report non LJE_NO_MORE_DATA_AVAILABLE error.
                    if(finished == false)
                        throw(e)
                    end
                end
            end
        end
        
        % Querys all measurements every 1 second
        if toc - timerPrev(2) >= readPeriod
            timerPrev(2) = toc;
            
            [psuData, psuMode] = psu.GetVoltCurrD();
            
            eloadData = eload.MeasureVoltCurr();
            
            ain2 = ain2 / adcAvgCount; ain3 = ain3 / adcAvgCount;
            
            % Grab new battery voltage and add offset
            battVolt = ain2 - ain3 + 0.011;
%             newBatteryVolt = ain2 - ain3 + 0.011;
%             
%             % In order to further minimize imprecision, this if statement
%             % compares the values of the new battery voltage to what it was
%             % in the last record. It does this by preventing the voltage
%             % from increasing 1mV during discharge and decrease 1mV while
%             % charging.
%             if chargeState == true && newBatteryVolt > battVolt
%                battVolt = newBatteryVolt;
%             elseif chargeState == false && newBatteryVolt - battVolt
%                battVolt = newBatteryVolt;
%             else
%                 % Leave battVolt as previous value
%                 
%                 % Updates the battery voltage for the first time.
%                 % Taking this off doesn't let the battVolt update for
%                 % the 1st time thereby reading 0.00 V
%                 if(toc <= readPeriod)
%                    battVolt = newBatteryVolt;
%                 end
%                 
%             end
            adcAvgCounter = 0; ain2 = adcAvgCounter; ain3 = adcAvgCounter;
            
            %Measure Data from thermometer. Since Data sent is multiplied by 10,
            %need to divide it by 10 to be understandable
            thermoData = read(thermo,'holdingregs',1,2);%/10;
            
            tElasped = toc - timerPrev(3);
            disp(num2str(tElasped,'%.1f') + "seconds");
            Pstr = sprintf("PSU Volt = %.3f V\t\tPSU Curr = %.3f A", psuData(1), psuData(2));
            Estr = sprintf("ELoad Volt = %.3f V\tELoad Curr = %.3f A",  eloadData(1), eloadData(2));
            Tstr = sprintf("TC 1 = %.1f �C\t\t\tTC 2 = %.1f �C" ,thermoData(1)/10, thermoData(2)/10);
            Bstr = sprintf("Batt Volt = %.3f V\t\tBatt State = %s\n\n", battVolt, battState);
            fprintf(Pstr + newline + Estr + newline + Tstr + newline + Bstr);
            
            dateString = datestr(datetime);
            dateTime = strsplit(dateString, ' ');
            
            fprintf(fileID,"%s,%s,",dateTime{1}, dateTime{2});
            fprintf(fileID,"%.1f,", tElasped);
            fprintf(fileID,"%.3f,%.3f,%s,", psuData(1), psuData(2), psuMode);
            fprintf(fileID,"%.3f,%.3f,",  eloadData(1), eloadData(2));
            fprintf(fileID,"%.1f,%.1f,",thermoData(1)/10, thermoData(2)/10);
            fprintf(fileID,"%.3f,%s\n", battVolt, battState);
            
        end
        
        
        % If the charge voltage is equal or greater than the high
        % voltage limit, change to discharge mode and viceversa if load
        % voltage is less than low voltage limit
        if (battVolt >= highVoltLimit) && (chargeState == true)
            chargeReq = false;
            chargeCounter = chargeCounter + 1;
        elseif (battVolt <= lowVoltLimit) && (dischargeState == true)
            chargeReq = true;
        end
        
        %% Fail Safes
        
        % if surface temperature > value, break loop
        if thermoData(2)/10 > battSurfTempLimit
            warning("WARNING - Surface Temp Exceeded Limit");
            fprintf(fileID,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",...
                "","","","","","","","","","","","",...
                "WARNING - Surface Temp Exceeded Limit");
            break;
        elseif battVolt <= minBattVoltLimit || battVolt >= maxBattVoltLimit
            warning("WARNING - Battery Voltage Exceeded Limit");
            fprintf(fileID,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",...
                "","","","","","","","","","","","",...
                "WARNING - Battery Voltage Exceeded Limit");
            break;
        end
        
    end
end

%% Teardown Section

%Close file
fclose(fileID);

% Puts the battery back in discharge mode
relayState = true;
ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,relayState, 0);
ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 5,relayState, 0);
ljudObj.Close();

% Disconnects both charger and discharger
psu.Disconnect();
eload.Disconnect();
