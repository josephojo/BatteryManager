tic;
% psu = BK_PSU('COM4');
% eload = Array_ELoad('COM2');
thermo = modbus('serialrtu','COM5','Timeout',10); % Initializes a Modbus
%protocol object using serial RTU interface connecting to COM6 and a Time
%out of 10s.
thermo.BaudRate = 38400;

ljasm = NET.addAssembly('LJUDDotNet');
ljudObj = LabJack.LabJackUD.LJUD;

% Open the first found LabJack U3.
[ljerror, ljhandle] = ljudObj.OpenLabJackS('LJ_dtU3', 'LJ_ctUSB', '0', ...
    true, 0);

% Constant values used in the loop.
LJ_ioGET_AIN = ljudObj.StringToConstant('LJ_ioGET_AIN');
LJ_ioGET_AIN_DIFF = ljudObj.StringToConstant('LJ_ioGET_AIN_DIFF');
LJE_NO_MORE_DATA_AVAILABLE = ljudObj.StringToConstant('LJE_NO_MORE_DATA_AVAILABLE');

% Start by using the pin_configuration_reset IOType so that all pin
% assignments are in the factory default condition.
ljudObj.ePutS(ljhandle, 'LJ_ioPIN_CONFIGURATION_RESET', 0, 0, 0);

%% BK Precision 1688B Power Supply (PSU) COMM Timing
timer1 = toc;

% psuData = zeros(1, 2);
[psuData, psuMode] = psu.GetVoltCurrD();
tElasped = toc - timer1;
disp(num2str(tElasped,'%.3f') + "seconds");
Pstr = sprintf("PSU Volt = %.3f V\t\tPSU Curr = %.3f A\n", psuData(1), psuData(2));
fprintf(Pstr + newline);

%% Array 3721A ELoad COMM Timing
% eload.SetSystCtrl("remote");
timer1 = toc;
% eloadData = zeros(1, 2);       
eloadData = eload.MeasureVoltCurr();
% eloadData = eload.MeasureVolt();
tElasped = toc - timer1;
disp(num2str(tElasped,'%.3f') + "seconds");
Estr = sprintf("ELoad Volt = %.3f V\tELoad Curr = %.3f A\n",  eloadData(1), eloadData(2));
% Estr = sprintf("ELoad Volt = %.3f V\n",  eloadData(1));
fprintf(Estr + newline);

%% Thermocouple DAQ Test through the thermocouple module and YN-4561 USB to Serial module COMM Timing
timer1 = toc;

thermoData = read(thermo,'holdingregs',9,3);%/10;
tElasped = toc - timer1;
disp(num2str(tElasped,'%.3f') + "seconds");
Tstr = sprintf("TC 1 = %.1f �C\t\t\tTC 2 = %.1f �C\t\t\tTC 3 = %.1f �C\n" ,thermoData(1)/10, thermoData(2)/10, thermoData(3)/10);
fprintf(Tstr + newline);

%% BK Precision 1688B Power Supply (PSU) Control Test
clear;
clc;

s = serial('COM4');
s.BaudRate = 9600;
s.DataBits = 8;
s.Parity = 'none';
s.StopBits = 1;
s.Terminator = 'CR';

% Open Port
fopen(s)

% Sending V or I values
fprintf(s,'VOLT090')
reply = fscanf(s);
disp(reply)

% Receiving V or I Values
fprintf(s,'GETS')
reply = fscanf(s);
disp(reply)
reply = fscanf(s);
disp(reply)
% Close Serial Port
fclose(s);

%% Thermocouple DAQ Test through the thermocouple module and YN-4561 USB to Serial module
clear;
m = modbus('serialrtu','COM4','Timeout',10); % Initializes a Modbus protocol object using serial RTU interface connectinf to COM4 (current, could change) and a Time out of 10s.

read(m,'holdingregs',1,1) %Reads "16" values (thermocouple port 1 to port 16) from the holding registers "holdingregs" of address "1" on RS-485 using function code 03.
                            %The equivalent of this is 01 03 00 00 00 10
                            %CRC CRC which is the required text to send
                            %according to the thermo module doc on https://www.aliexpress.com/item/16-road-support-mix-PT100-K-T-J-N-E-S-4-20mA-thermocouple-thermal-resistance/32901795740.html?spm=2114.search0104.3.2.2f995c71hQ9X4m&ws_ab_test=searchweb0_0,searchweb201602_2_10065_10068_10130_10547_319_317_10548_10696_10924_453_10084_454_10083_10618_10139_10920_10921_10307_10922_537_536_10059_10884_10887_100031_321_322_10103,searchweb201603_51,ppcSwitch_0&algo_expid=3ec3e6b6-d45c-4224-be36-e1e004c5d5e2-0&algo_pvid=3ec3e6b6-d45c-4224-be36-e1e004c5d5e2

%% Array ELoad Control Test
clear;
clc;

eLoad = serial('COM2');
eLoad.BaudRate = 9600;
eLoad.DataBits = 8;
eLoad.Parity = 'none';
eLoad.StopBits = 1;
eLoad.Terminator = 'LF';

% Open Port
fopen(eLoad)

% Sending V or I values
fprintf(eLoad,'SYST:REM')
% reply = fscanf(eLoad);
% disp("reply")

% Receiving V or I Values
fprintf(eLoad,'CURR:LEV 3')
% reply = fscanf(eLoad);
% disp(reply)
% reply = fscanf(eLoad);
% disp(reply)

fprintf(eLoad,'SYST:LOC')

% Close Serial Port
fclose(eLoad);

%% Labjack Relay control and Voltage Measurement
clc;
ljasm = NET.addAssembly('LJUDDotNet');
ljudObj = LabJack.LabJackUD.LJUD;

try
    % Read and display the UD version.
    disp(['UD Driver Version = ' num2str(ljudObj.GetDriverVersion())])

    % Open the first found LabJack U3.
    [ljerror, ljhandle] = ljudObj.OpenLabJackS('LJ_dtU3', 'LJ_ctUSB', '0', true, 0);

    % Start by using the pin_configuration_reset IOType so that all pin
    % assignments are in the factory default condition.
    ljudObj.ePutS(ljhandle, 'LJ_ioPIN_CONFIGURATION_RESET', 0, 0, 0);
    
    tic;
    t1 = toc;
    state = true;
    for i = 1:10
        disp (i)
        while (t < 3)
            t2 = toc;
            t = t2 - t1;
        end
        state = ~state;
        disp ("state = " + state);%disp (state)
        ljudObj.ePutS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4,state, 0); 
        t1 = t2;t=0;
    end
    
catch e
    showErrorMessage(e)
end

%% Labjack Relay control and Voltage Measurement Average Timing
ain3 = 0; ain2 = 0; adcAvgCounter = 0;
adcAvgCount = 50;

timer1 = toc;

 % Due to the imprecision of the Labjack ADC (12bit)or 5mV variation
    % This section averages 50 individual values from 2 analog ports
    % vBattp (Vbatt+) and vBattn(Vbatt-) to stabilize the voltage
    % difference and attain a variation of �0.001 V or �1 mV
    while adcAvgCounter < adcAvgCount
        
        % Request a single-ended reading from AIN2 (VBatt+).
        ljudObj.AddRequestS(ljhandle, 'LJ_ioGET_AIN', 2, 0, 0, 0);
        
        % Request a single-ended reading from (VBatt-).
        ljudObj.AddRequestS(ljhandle, 'LJ_ioGET_AIN', 3, 0, 0, 0);
        %
        % Execute the requests.
        ljudObj.GoOne(ljhandle);
        
        [ljerror, ioType, channel, dblValue, dummyInt, dummyDbl] = ljudObj.GetFirstResult(ljhandle, 0, 0, 0, 0, 0);
        
        finished = false;
        while finished == false
            switch ioType
                case LJ_ioGET_AIN
                    switch int32(channel)
                        case 2
                            ain2 = ain2 + dblValue;
                        case 3
                            ain3 = ain3 + dblValue;
                    end
            end
            
            try
                [ljerror, ioType, channel, dblValue, dummyInt, dummyDbl] = ljudObj.GetNextResult(ljhandle, 0, 0, 0, 0, 0);
            catch e
                if(isa(e, 'NET.NetException'))
                    eNet = e.ExceptionObject;
                    if(isa(eNet, 'LabJack.LabJackUD.LabJackUDException'))
                        % If we get an error, report it. If the error is
                        % LJE_NO_MORE_DATA_AVAILABLE we are done.
                        if(int32(eNet.LJUDError) == LJE_NO_MORE_DATA_AVAILABLE)
                            finished = true;
                            adcAvgCounter = adcAvgCounter + 1;
                        end
                    end
                end
                % Report non LJE_NO_MORE_DATA_AVAILABLE error.
                if(finished == false)
                    throw(e)
                end
            end
        end
    end
    
    disp("Averaging time: " + num2str(toc - timer1,'%.3f') + "seconds");
    %Finds avg of total voltages collected at both batt terminals
    vBattp = ain2 / adcAvgCount;
    vBattn = ain3 / adcAvgCount;

    % Grabs new battery voltage and adds offset
    battVolt = vBattp - vBattn + 0.011;
    
    disp("battVolt: " + num2str(battVolt,'%.3f'))
    
    %% TearDown
    resetDevices; % Run script