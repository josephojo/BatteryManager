function wait(seconds)
%wait Pauses the program from running
%   Uses the tic, toc matlab properties to halt the program for the
%   specified number of seconds (s)
if seconds > 10
    disp('Waiting');
end

try
    t1 = toc;
catch
    tic;
    t1 = toc;
end
t = 0;

while (t < seconds)
    t2 = toc;
    t = t2 - t1;
end

t1 = t2;
t=0;

if seconds > 10
    disp('Done');
end

end

