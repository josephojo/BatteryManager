function battTS = heatTillTime(seconds, heatPad, varargin)
%heatTillTime Turns on the heatpad until the specified number of seconds

% clearvars;
try
cellID = 'AA5';

script_initializeDevices;
script_initializeVariables;

verbose = 1;
script_idle;

% script_queryData;

heatPadStartTime = seconds * 0.2; %100.0;
if nargin > 2 && strcmpi(class(varargin{1}),'double')
    heatPadEndTime = heatPadStartTime + varargin{1}; %220.0;
elseif nargin == 2 && seconds < 10
    heatPadEndTime = heatPadStartTime + seconds - 2;
else
    heatPadEndTime = heatPadStartTime + 10;
end
heatPadTimeTol = 0.5;

disp("Waiting for " + num2str(seconds) + " Seconds!");
t1 = toc;
t = 0;

while (t < seconds)
    if toc - timerPrev(3) >= readPeriod
        timerPrev(3) = toc;
        script_queryData; % Runs the script that queries data from the devices. Stores the results in the [dataCollection] Variable
         % HEATING PAD
        if heatPad==true
            % The Relay that was origninally used for an LED has been repurposed
            % for the heating pad. The pad switches on heatPadStartTime (+5s)
            % and switches OFF heatPadEndTime (+5s)
            if t >= heatPadStartTime && t < heatPadStartTime + heatPadTimeTol
                disp("Heat Pad Turned ON - " + num2str(tElasped))
                % Make sure the heating pad is ON
                ljudObj.AddRequestS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4, true, 0, 0);
                ljudObj.GoOne(ljhandle);
            elseif t >= heatPadEndTime && t < heatPadEndTime + heatPadTimeTol
                disp("Heat Pad Turned OFF" + num2str(tElasped))
                % Make sure the heating pad is ON
                ljudObj.AddRequestS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', 4, false, 0, 0);
                ljudObj.GoOne(ljhandle);
            end
        end
    end
    
    t2 = toc;
    t = t2 - t1;
end

t1 = t2;
t=0;

script_resetDevices;

catch ME
    script_resetDevices;
    rethrow(ME);
end
% clearvars;
end
