function battTS = waitTillTime(seconds, varargin)
%waitTillTemp Pauses the program from running until the Core Temp equals the surf
%Temp
%   Halts the program while Temp and Core Temp values converge
% clearvars;
try
    
    param = struct('cellIDs',        [],...
                'trig1',            false,...
                'trig1_pin',        4,...
                'trig1_startTime',  [10.0],...
                'trig1_duration',   [2.0]);


    % read the acceptable names
    paramNames = fieldnames(param);

    % Ensure variable entries are pairs
    nArgs = length(varargin);
    if round(nArgs/2)~=nArgs/2
       error('runProfile needs propertyName/propertyValue pairs')
    end

    for pair = reshape(varargin,2,[]) %# pair is {propName;propValue}
       inpName = pair{1}; %# make case insensitive

       if any(strcmpi(inpName,paramNames))
          %# overwrite options. If you want you can test for the right class here
          %# Also, if you find out that there is an option you keep getting wrong,
          %# you can use "if strcmp(inpName,'problemOption'),testMore,end"-statements
          param.(inpName) = pair{2};
       else
          error('%s is not a recognized parameter name',inpName)
       end
    end

% ---------------------------------
cellIDs = param.cellIDs;
    
    disp("Waiting for " + num2str(seconds) + " Seconds!");
    
    script_initializeDevices;
    script_initializeVariables;
    t1 = toc;
    t = 0;
    
    verbose = 1;
    
    trig1_On = false;
    trig1_Ind = 1; % Index for iterating over the start times specified for trig1
    
    battState = "idle";
    
    script_queryData;
    
    if param.trig1 == true
        trig1StartTime = param.trig1_startTime;
        trig1EndTime = param.trig1_startTime + param.trig1_duration;
        trig1TimeTol = 0.5; % Half a second    
    end
    
    while (t < seconds)
        t2 = toc;
        t = t2 - t1;
        
        if toc - timerPrev(3) >= readPeriod
            timerPrev(3) = toc;
            script_queryData; % Runs the script that queries data from the devices. Stores the results in the [dataCollection] Variable
        end
        % Trigger1 (GPIO from LabJack)
        if param.trig1==true
            % The trigger is activated on trig1StartTime
            % and switches OFF trig1EndTime
            if tElasped >= trig1StartTime(trig1_Ind) && ...
                    tElasped < trig1StartTime(trig1_Ind) + trig1TimeTol && ...
                    trig1_On == false
                disp("Trigger ON - " + num2str(timerPrev(3))+ newline)
                pinVal = true;
                % Make sure the heating pad is ON
                ljudObj.AddRequestS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', param.trig1_pin, pinVal, 0, 0);
                ljudObj.GoOne(ljhandle);
                trig1_On = true;
            elseif tElasped >= trig1EndTime(trig1_Ind) && ...
                    tElasped < trig1EndTime(trig1_Ind) + trig1TimeTol && ... 
                    trig1_On == true
                disp("Trigger OFF - " + num2str(timerPrev(3))+ newline)
                % Make sure the heating pad is ON
                ljudObj.AddRequestS(ljhandle,'LJ_ioPUT_DIGITAL_BIT', param.trig1_pin, ~pinVal, 0, 0);
                ljudObj.GoOne(ljhandle);
                trig1_On = false;
                if length(trig1StartTime) > 1 && trig1_Ind ~= length(trig1StartTime)
                    trig1_Ind = trig1_Ind + 1;
                end
            end
        end
    end
    
    t1 = t2;
    t=0;
    
    disp("Waiting Done" + newline);
    
    script_resetDevices;
    
catch ME
    script_resetDevices;
    rethrow(ME);
end
% clearvars;
end
