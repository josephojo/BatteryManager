try 
    MCP2210_catchErrs(-1);
catch ME
    disp("Looks like it triggers the error in the try outside the function");
    rethrow(ME);
end