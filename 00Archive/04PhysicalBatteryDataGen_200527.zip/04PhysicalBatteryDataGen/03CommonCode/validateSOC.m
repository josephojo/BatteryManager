% This script validates the SOC of the battery by charging it to 100% SOC 
plotFigs = true;
chargeToFull; % Run the code that charges the code to 100% SOC
